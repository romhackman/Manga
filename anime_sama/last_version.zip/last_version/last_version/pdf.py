import os
import re
from PIL import Image
import tkinter as tk
from tkinter import filedialog, messagebox

def natural_sort_key(s):
    return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', s)]

def creer_pdf(dossier_chapitre):
    images = []
    fichiers = sorted(os.listdir(dossier_chapitre), key=natural_sort_key)

    for fichier in fichiers:
        if fichier.lower().endswith((".jpg", ".jpeg", ".png")):
            chemin = os.path.join(dossier_chapitre, fichier)
            img = Image.open(chemin).convert('RGB')
            images.append(img)

    if not images:
        return False, "Aucune image trouvée"

    # Nom du chapitre
    nom_chapitre = os.path.basename(dossier_chapitre)
    dossier_parent = os.path.dirname(dossier_chapitre)
    chemin_pdf = os.path.join(dossier_parent, f"{nom_chapitre}.pdf")

    try:
        images[0].save(chemin_pdf, save_all=True, append_images=images[1:])
        return True, chemin_pdf
    except Exception as e:
        return False, str(e)

# --- Mode normal : un seul chapitre ---
def mode_normal():
    dossier_chapitre = filedialog.askdirectory(title="Choisir un dossier de chapitre (images)")
    if not dossier_chapitre:
        return

    ok, msg = creer_pdf(dossier_chapitre)
    if ok:
        messagebox.showinfo("Succès", f"PDF créé :\n{msg}")
    else:
        messagebox.showerror("Erreur", msg)

# --- Mode boosté : plusieurs chapitres ---
def mode_boost():
    dossier_racine = filedialog.askdirectory(title="Choisir le dossier contenant les chapitres")
    if not dossier_racine:
        return

    sous_dossiers = [os.path.join(dossier_racine, d) for d in os.listdir(dossier_racine)
                     if os.path.isdir(os.path.join(dossier_racine, d))]

    if not sous_dossiers:
        messagebox.showerror("Erreur", "Aucun chapitre trouvé (aucun sous-dossier).")
        return

    resultats = []
    for dossier in sorted(sous_dossiers, key=natural_sort_key):
        ok, msg = creer_pdf(dossier)
        resultats.append(f"{os.path.basename(dossier)} → {'OK' if ok else 'Erreur'} ({msg})")

    messagebox.showinfo("Terminé", "\n".join(resultats))

# --- Mode Full PDF : un seul PDF pour tous les chapitres ---
def mode_full_pdf():
    dossier_racine = filedialog.askdirectory(title="Choisir le dossier contenant tous les chapitres")
    if not dossier_racine:
        return

    sous_dossiers = [os.path.join(dossier_racine, d) for d in os.listdir(dossier_racine)
                     if os.path.isdir(os.path.join(dossier_racine, d))]

    if not sous_dossiers:
        messagebox.showerror("Erreur", "Aucun chapitre trouvé (aucun sous-dossier).")
        return

    toutes_images = []

    for dossier in sorted(sous_dossiers, key=natural_sort_key):
        fichiers = sorted(os.listdir(dossier), key=natural_sort_key)
        for fichier in fichiers:
            if fichier.lower().endswith((".jpg", ".jpeg", ".png")):
                chemin = os.path.join(dossier, fichier)
                img = Image.open(chemin).convert('RGB')
                toutes_images.append(img)

    if not toutes_images:
        messagebox.showerror("Erreur", "Aucune image trouvée dans les chapitres.")
        return

    chemin_pdf = os.path.join(dossier_racine, "Tout_les_chapitres.pdf")

    try:
        toutes_images[0].save(chemin_pdf, save_all=True, append_images=toutes_images[1:])
        messagebox.showinfo("Succès", f"PDF complet créé :\n{chemin_pdf}")
    except Exception as e:
        messagebox.showerror("Erreur", str(e))

# --- Interface ---
fenetre = tk.Tk()
fenetre.title("Créer un PDF à partir d'images")
fenetre.geometry("450x250")

tk.Label(fenetre, text="Choisissez un mode").pack(pady=20)

tk.Button(fenetre, text="Mode normal : PDF pour 1 chapitre", command=mode_normal).pack(pady=5)
tk.Button(fenetre, text="Mode boosté : PDF pour tous les chapitres", command=mode_boost).pack(pady=5)
tk.Button(fenetre, text="Mode Full PDF : 1 PDF pour tous les chapitres", command=mode_full_pdf).pack(pady=5)

# Ajouter un logo à la fenêtre
try:
    logo = tk.PhotoImage(file="../logo.png")
    fenetre.iconphoto(False, logo)
except Exception as e:
    print(f"Impossible de charger le logo : {e}")
fenetre.mainloop()
