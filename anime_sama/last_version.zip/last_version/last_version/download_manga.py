import os
import requests
from PIL import Image
from io import BytesIO

# Dossier de base
base_folder = os.path.join(os.path.expanduser("~"), "Downloads", "Images")
os.makedirs(base_folder, exist_ok=True)

# URLs des images (extraites de ton premier message, pour les 36 images)
chapter = [

]


# Headers d'un vrai navigateur
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    "Accept-Language": "fr-FR,fr;q=0.9",
    "Referer": "https://www.example.com/",   # IMPORTANT pour éviter 403
    "Connection": "keep-alive"
}

session = requests.Session()
session.headers.update(headers)

def download(url, path):
    try:
        r = session.get(url, timeout=15)
        if r.status_code != 200:
            print(f"❌ {r.status_code} → {url}")
            return

        img = Image.open(BytesIO(r.content))
        # Conversion forcée en JPG
        rgb_img = img.convert("RGB")
        rgb_img.save(path, format="JPEG")
        print(f"✔ Téléchargé : {path}")

    except Exception as e:
        print(f"❌ Erreur : {e}")

# Téléchargement
chap_folder = os.path.join(base_folder, "Chapitre_1")
os.makedirs(chap_folder, exist_ok=True)

for i, url in enumerate(chapter, start=1):
    path = os.path.join(chap_folder, f"page_{i}.jpg")
    download(url, path)

print("✔ Terminé")
