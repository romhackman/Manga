import os
import requests
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

# ----------------- Thème Anti-Piratage -----------------
FOND = "#000000"
BLEU = "#00A2FF"
ROUGE = "#FF2A2A"
GRIS = "#222222"

ENTREE_BG = "#0D0D0D"
TEXTE = BLEU
BOUTON_BG = "#111111"

dossier_principal = ""

def appliquer_theme(widget):
    """Applique les couleurs à tous les widgets."""
    for element in widget.winfo_children():
        try:
            element.configure(bg=FOND, fg=TEXTE)
        except:
            pass

        if isinstance(element, tk.Entry):
            element.configure(bg=ENTREE_BG, fg=TEXTE, insertbackground=TEXTE)

        if isinstance(element, tk.Button):
            element.configure(
                bg=BOUTON_BG,
                fg=TEXTE,
                activebackground=GRIS,
                activeforeground=ROUGE
            )

        appliquer_theme(element)


def choisir_dossier():
    global dossier_principal
    dossier = filedialog.askdirectory(title="Choisir le dossier principal pour enregistrer le manga")
    if dossier:
        dossier_principal = dossier
        texte_dossier.set(f"Dossier sélectionné : {dossier_principal}")


def telecharger_chapitre(url_base, nb_pages, dossier_chapitre, compteur_total, total_pages):
    if not os.path.exists(dossier_chapitre):
        os.makedirs(dossier_chapitre)

    for numero in range(1, nb_pages + 1):
        url_image = url_base.replace("NUM", str(numero))
        nom_fichier = os.path.join(dossier_chapitre, f"page_{numero}.jpg")

        try:
            texte_status.set(f"Téléchargement : {os.path.basename(dossier_chapitre)} page {numero}/{nb_pages}")
            fenetre.update()

            data = requests.get(url_image, headers={"User-Agent": "Mozilla/5.0"}).content
            with open(nom_fichier, "wb") as f:
                f.write(data)

            compteur_total[0] += 1
            progress = (compteur_total[0] / total_pages) * 100
            barre_progression['value'] = progress
            fenetre.update()

        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de télécharger : {url_image}\n{e}")
            return


def telecharger_manga():
    global dossier_principal
    url_base = entree_url.get().strip()
    titre_manga = entree_titre.get().strip()

    if not titre_manga:
        messagebox.showerror("Erreur", "Vous devez donner un titre pour le manga.")
        return

    if not dossier_principal:
        messagebox.showerror("Erreur", "Vous devez sélectionner un dossier principal.")
        return

    if "NUM" not in url_base or "CHAP" not in url_base:
        messagebox.showerror("Erreur", "Le lien doit contenir 'CHAP' et 'NUM'.")
        return

    dossier_manga = os.path.join(dossier_principal, titre_manga)
    if not os.path.exists(dossier_manga):
        os.makedirs(dossier_manga)

    choix = messagebox.askquestion(
        "Méthode",
        "Voulez-vous définir un intervalle ?\n\n"
        "- OUI : début → fin\n"
        "- NON : début + quantité"
    )

    if choix == "yes":
        chapitre_debut = simpledialog.askinteger("Début", "Chapitre de début :")
        chapitre_fin = simpledialog.askinteger("Fin", "Chapitre de fin :")
        if not chapitre_debut or not chapitre_fin or chapitre_fin < chapitre_debut:
            messagebox.showerror("Erreur", "Intervalle invalide.")
            return
        liste_chapitres = list(range(chapitre_debut, chapitre_fin + 1))
    else:
        chapitre_debut = simpledialog.askinteger("Début", "Chapitre de départ :")
        quantite = simpledialog.askinteger("Quantité", "Nombre de chapitres :")
        if not chapitre_debut or not quantite:
            messagebox.showerror("Erreur", "Valeurs invalides.")
            return
        liste_chapitres = list(range(chapitre_debut, chapitre_debut + quantite))

    pages_par_chapitre = {}
    for chapitre in liste_chapitres:
        nb_pages = simpledialog.askinteger("Pages", f"Nombre de pages pour le chapitre {chapitre} ?")
        if not nb_pages:
            messagebox.showerror("Erreur", f"Pages invalides pour le chapitre {chapitre}.")
            return
        pages_par_chapitre[chapitre] = nb_pages

    total_pages = sum(pages_par_chapitre.values())
    compteur_total = [0]

    for chapitre in liste_chapitres:
        texte_status.set(f"Téléchargement : Chapitre {chapitre}")
        fenetre.update()
        dossier_chapitre = os.path.join(dossier_manga, f"Chapitre_{chapitre}")
        url_chapitre = url_base.replace("CHAP", str(chapitre))

        telecharger_chapitre(url_chapitre, pages_par_chapitre[chapitre],
                             dossier_chapitre, compteur_total, total_pages)

    messagebox.showinfo("Terminé", "Tous les chapitres ont été téléchargés !")
    texte_status.set("Téléchargement terminé.")
    barre_progression['value'] = 0


# -------------------------------------------------------
# Interface principale
# -------------------------------------------------------
fenetre = tk.Tk()
fenetre.title("MANGA DOWNLOADER")
fenetre.geometry("720x380")
fenetre.configure(bg=FOND)

# Ajouter un logo à la fenêtre
try:
    logo = tk.PhotoImage(file="logo.png")
    fenetre.iconphoto(False, logo)
except Exception as e:
    print(f"Impossible de charger le logo : {e}")

# Style ProgressBar
style = ttk.Style()
style.theme_use("clam")
style.configure("TProgressbar",
                troughcolor="#111111",
                background=BLEU,
                bordercolor="#000000")

tk.Label(fenetre, text="Titre du manga :", bg=FOND, fg=TEXTE).pack(pady=5)
entree_titre = tk.Entry(fenetre, width=60, bg=ENTREE_BG, fg=TEXTE, insertbackground=TEXTE)
entree_titre.pack()

tk.Label(fenetre, text="Lien modèle (CHAP / NUM) :", bg=FOND, fg=TEXTE).pack(pady=5)
entree_url = tk.Entry(fenetre, width=80, bg=ENTREE_BG, fg=TEXTE, insertbackground=TEXTE)
entree_url.pack()

bouton_dossier = tk.Button(fenetre, text="Choisir le dossier principal", command=choisir_dossier,
                           bg=BOUTON_BG, fg=TEXTE)
bouton_dossier.pack(pady=10)

texte_dossier = tk.StringVar()
texte_dossier.set("Aucun dossier sélectionné")
tk.Label(fenetre, textvariable=texte_dossier, bg=FOND, fg=TEXTE).pack()

barre_progression = ttk.Progressbar(
    fenetre, orient="horizontal", length=600, mode="determinate", style="TProgressbar")
barre_progression.pack(pady=15)

bouton = tk.Button(fenetre, text="Télécharger le manga", command=telecharger_manga,
                   bg=BOUTON_BG, fg=TEXTE)
bouton.pack(pady=10)

texte_status = tk.StringVar()
texte_status.set("En attente…")
tk.Label(fenetre, textvariable=texte_status, bg=FOND, fg=TEXTE).pack()

appliquer_theme(fenetre)
fenetre.mainloop()
